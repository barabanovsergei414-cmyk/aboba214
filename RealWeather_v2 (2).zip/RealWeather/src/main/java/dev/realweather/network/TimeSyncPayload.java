package dev.realweather.network;

import dev.realweather.RealWeather;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Время суток и скорость его хода (тиков суток за игровой тик) — клиент интерполирует небо плавно. */
public record TimeSyncPayload(long dayTime, float rate) implements CustomPacketPayload {
    public static final Type<TimeSyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(RealWeather.MODID, "time_sync"));
    public static final StreamCodec<RegistryFriendlyByteBuf, TimeSyncPayload> CODEC =
            StreamCodec.ofMember(TimeSyncPayload::write, TimeSyncPayload::read);

    public void write(RegistryFriendlyByteBuf buf) {
        buf.writeLong(dayTime);
        buf.writeFloat(rate);
    }

    public static TimeSyncPayload read(RegistryFriendlyByteBuf buf) {
        return new TimeSyncPayload(buf.readLong(), buf.readFloat());
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
